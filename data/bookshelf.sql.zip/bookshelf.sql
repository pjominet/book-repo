--
-- Datenbank: `bookshelf`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` text COLLATE utf32_unicode_ci,
  `author` text COLLATE utf32_unicode_ci,
  `ISBN` char(17) COLLATE utf32_unicode_ci DEFAULT NULL,
  `pages` int(11) DEFAULT NULL,
  `abstract` text COLLATE utf32_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_unicode_ci;

--
-- Daten für Tabelle `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `ISBN`, `pages`, `abstract`) VALUES
(1, 'About John Doe', 'Ivan Ivanonvic', '123-4-56789-012-3', 420, 'A biography about John Doe and his relationship to Max Mustermann.'),
(2, 'Lorem Ipsum', 'Julius Publius', '987-6-54321-012-3', 100, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas dictum ante ut dolor malesuada pulvinar. Suspendisse vitae facilisis tellus. Aenean imperdiet quam sed urna pellentesque, vel rhoncus lorem blandit. In tincidunt elit eu nisi fermentum, a fringilla justo ultrices. Sed laoreet urna vel posuere commodo. Maecenas efficitur, nunc a pharetra dictum, mauris diam rhoncus ipsum, id laoreet nisl elit vitae nisi. Vivamus vestibulum libero maximus, sagittis tellus sit amet, commodo justo.'),
(3, 'Programmers daily life', 'Winzig Weich', '337-4-56745-101-8', 1337, 'Overload associative operation ocaml access violation complementarity endian assembler dynamic dump ecmascript advanced scsi programming interface. Strong typed language eclipse array cpan ocaml jvm programming dead code pastebin branch jcl method overloading. Phrase tag background thread %1 repeat counter llvm overflow error r programming language shell scripts. Generation language java me programmable rust dml hex editor programming language odbc data type xsl. Public pdl array of pointers source code discrete optimization content migration parenthesis do bom machine language. Algorithm lambda calculus overflow error pseudo-operation local optimum javac glitch escape programming language.'),
(4, 'Der Kalligraph des Bischofs', 'Titus Mueller', '978-3-45347-137-5', 400, 'Turin im 9. Jahrhundert: Während die Stadt von den Sarazenen bedroht wird, wird der Westgote Claudius dorthin als neuer Bischof entsandt. Er nimmt Germunt an seinen Hof, einen Gelehrten, der in der Stadt Zuflucht vor seinen Bluträchern gesucht hat. Germunt bekommt die Erlaubnis, in den sieben freien Künsten zu unterrichten, und gerät bald in den Bann des Schreibens wie der Liebe, dringt tiefer in die Geheimnisse der Kalligraphie ein und muss eines Tages seine Kunst anwenden, um Leben zu retten.'),
(5, 'Erbe und Schicksal', 'Jeffrey Archer', '978-3-45347-136-8', 576, 'England 1945: Der Zweite Weltkrieg ist beendet. Harry Clifton, der sich aus den Hafendocks Bristols hochgearbeitet hat, und sein treuer Jugendfreund Giles Barrington, Sprössling der Schifffahrt-Dynastie Barrington, haben überlebt. Endlich hat Harry zu seiner großen Liebe gefunden, zu Giles Schwester Emma Barrington. Doch ein langer Schatten droht auf die jungen Menschen zu fallen. In einer dramatischen Verhandlung obliegt es dem Haus der Lords festzulegen, wer das Vermögen der Barringtons rechtmaessig erben wird: Harry oder Giles. Harry weiss, dass die Entscheidung seine Verbindung mit Emma für immer zerstören könnte. Für die Familien Clifton und Barrington beginnt eine neue Epoche voller Intrigen und Verrat.'),
(6, 'Die Reise der Amy Snow', 'Tracy Rees', '978-3-47135-136-9', 480, 'Ein Buch über zwei ungleiche Frauen, deren Freundschaft bis weit über den Tod hinaus andauert. Als Baby wurde Amy Snow ausgesetzt. Mittellos und von allen gehasst wird sie auf dem noblen Hatville Court aufgezogen. Die schöne Tochter des Hauses, Aurelia Vennaway, ist Amys einzige Freundin und der wichtigste Mensch in ihrem Leben. Als Aurelia jung stirbt, bricht Amys Welt zusammen. Aber Aurelia macht ihr ein letztes Geschenk: Ein Bündel Briefe, das Amy auf Schatzsuche schickt. Einen Code, den nur Amy entschlüsseln kann. Am Ende erwartet Amy ein Geheimnis, das ihr Leben verändern wird. Amy Snow begibt sich auf eine Reise quer durch England. '),
(7, 'Pig meat Lexicon', 'Dorothee Piggy', '122-4-10110-666-8', 123, 'Tenderloin sausage flank round mignon ribs tongue tail kielbasa t-bone shankle venison ribs. Pastrami doner bacon pig belly doner round beef strip jowl bacon pig tail. Pastrami frankfurter belly tongue chop pork hamburger ball swine shank pig ground venison shank. Cupim bacon jowl t-bone t-bone bresaola brisket andouille boudin shank ribeye short.'),
(8, 'How to Hipster', 'Jan Beardson', '951-5-48526-753-5', 12, 'Ethical next level truck gluten-free up Boogie-woogie next level jean shorts hella biodiesel sustainable intelligentsia. Up sustainable truck next level Boogie-woogie cronut rights Boogie-woogie deep Bree crucifix Portland. High life up biodiesel axe Break Bright slow-carb bicycle rights gluten-free Bree next level. Brightnin'' next level Blow axe Echo Park readymade food cronut axe Brightnin''. Ethical hella Portland narwhal food gluten-free up Bree deep bicycle Boot gluten-free Boot.'),
(9, 'The World of Coffee', 'Karl Cupbored', '369-2-42685-147-5', 50, 'Carajillo sugar robusta to so latte Affogato to-go milk qui lungo steamed robust beans Coffee. Organic black foam macchiato aroma rich con cappuccino steamed arabica sit seasonal affogato cup. Fair steamed robust redeye doppio Variety cultivar sit Cultivar Galão shop panna rich aged pumpkin. Americano black fair grounds Dark arabica steamed redeye latte Affogato doppio organic trade. Origin half mug rich rich variety Variety aromatic chicory aged that cappuccino irish.'),
(10, 'Das Leben des Brian', 'Monty Python', '123-4-56789-101-1', 666, 'Always look on the bright side of life. What have the romans ever done for us, but Aquaeducts. Roads! Public order! '),
(11, 'Doge Chronicles', 'The Almighty Doge', '951-4-28465-159-7', 7, 'All hail Doge! Wow intensifies. Such book, much awesome. Very read.'),
(12, 'Per Anhalter durch die Galaxis', 'Douglas Adams', '258-6-62487-741-9', 42, 'Die Geschichte, die allen Versionen zugrunde liegt, sind die Abenteuer des Arthur Dent, eines Durchschnittsengländers, der mit knapper Not und mit Hilfe seines Freundes Ford Prefect der totalen Zerstörung des Planeten Erde durch eine außerirdische Rasse namens Vogonen entgeht. Zu Arthurs Verblüffung erweist sich sein Freund als außerirdischer Besucher, der die Erde zu Recherchezwecken wegen eines galaktischen Nachschlagewerks bereiste und zu dessen Unglück sich für einige Jahre keine Weiterreisemöglichkeit ergeben hatte. Als die Flotte der Vogonen auftaucht, um die Erde zwecks Baus einer galaktischen Hyperraum-Expressroute zu zerstören, nutzt Ford die Gelegenheit und bringt sich und Arthur mittels „Subraum-Äther-Winker“ (Sub-Etha-Sens-O-Matic, eine Art elektronischer Daumen) sozusagen per Anhalter an Bord eines der Vogonenraumschiffe.'),
(13, 'Necronomicon', 'Cthulu', '784-3-79462-462-8', 888, 'Ph’nglui mglw’nafh Cthulhu R’lyeh wgah’nagl fhtagn.');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
